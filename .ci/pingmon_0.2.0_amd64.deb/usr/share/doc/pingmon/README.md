# Pingmon

Monitor connections to one or more endpoints, and send the results to one or more backends.

... eventually.

# Status

Currently, development is focused on:

1. Loading config
2. Executing traceroute to CLI
3. OPTIONALLY Sending results to influxdb
4. Proper linux installation (systemd, config, etc)
5. Cross compilation for rasp pi (the desired platform)

# Future

1. Support other endpoints (which?)

# Contributing

There are no contributor guidelines at the moment, but feel free to file an issue or open an PR for discussion.
